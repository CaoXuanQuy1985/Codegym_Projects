package com.codegym.readFile;

import java.util.*;

public class MysqlStorage implements CourseStorage {
    @Override
    public void read(String sourcePath) {}
    @Override
    public List<InformationCourse> getListCourses(){
        return new ArrayList<>();
    }
}
